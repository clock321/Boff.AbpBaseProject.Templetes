﻿
//IAuthorizeCacheService.cs
using System;
using System.Threading.Tasks;

namespace Boff.Blog.Application.Caching.Authorize
{
    public interface IAuthorizeCacheService
    {
        /// <summary>
        /// 获取登录地址(GitHub)
        /// </summary>
        /// <returns></returns>
        Task<string> GetLoginAddressAsync(Func<Task<string>> factory);

        /// <summary>
        /// 获取AccessToken
        /// </summary>
        /// <param name="code"></param>
        /// <param name="factory"></param>
        /// <returns></returns>
        Task<string> GetAccessTokenAsync(string code, Func<Task<string>> factory);

        /// <summary>
        /// 登录成功，生成Token
        /// </summary>
        /// <param name="access_token"></param>
        /// <param name="factory"></param>
        /// <returns></returns>
        Task<string> GenerateTokenAsync(string access_token, Func<Task<string>> factory);
    }
}