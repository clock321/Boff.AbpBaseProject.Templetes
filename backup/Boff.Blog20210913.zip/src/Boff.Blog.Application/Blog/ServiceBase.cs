﻿namespace Boff.Blog.Blog
{
    public class ServiceBase
    {
    }
}