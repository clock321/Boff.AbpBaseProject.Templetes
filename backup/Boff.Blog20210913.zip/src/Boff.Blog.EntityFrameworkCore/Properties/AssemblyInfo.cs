﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Boff.Blog.EntityFrameworkCore.Tests")]
