﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Boff.Blog.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("Boff.Blog.TestBase")]
