﻿namespace Boff.Blog
{
    public static class BlogDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
