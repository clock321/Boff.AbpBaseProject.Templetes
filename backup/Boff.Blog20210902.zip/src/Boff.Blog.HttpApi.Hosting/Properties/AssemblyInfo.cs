﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Boff.Blog.Web.Tests")]
