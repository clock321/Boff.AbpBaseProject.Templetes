﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Boff.Blog.Application.Tests")]
